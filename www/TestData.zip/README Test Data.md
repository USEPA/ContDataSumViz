# README Test Data



The provided test data consist of continuous and discrete observations from Posey Creek: a National Ecological Observatory Network (NEON) Core Aquatic site located on the Smithsonian Conservation Biology Institute near Front Royal, VA. The data are formatted from NEON data products, and the relevant citations are included below. 



##### Site information:

Posey Creek (38.89431, -78.147258) is a small wadeable stream with a 2 km2 watershed. For more information about this site, visit the NEON site page for Posey Creek:  https://www.neonscience.org/field-sites/pose. 



##### Data:

The data are formatted for compatibility with ContDataSumViz. Each file contains one mandatory header with a site identification column (SiteID), date/time (DateTime), columns with parameters (e.g., Discharge), and (for the continuous data) columns with quality flags (e.g., DischargeQF). The quality flag columns names contain the continuous parameter name appended with "QF." Observations passing quality checks are assigned a "0" in the respective quality flag column and "1" if the observation failed the quality check. These data only include "Fail" quality flags, not "Suspect" or "Not known."



Date/times are provided in ISO 8601 format. Date in year, month, day format is separated from time in hours, minutes, seconds format with the character `T.` The time zone follows, which is represented as the deviation from coordinated universal time (UTC) with the letter `Z`. No number after `Z` indicates that the data from Posey Creek are in UTC time zone.



###### PoseyCreek\_continuous.csv

**Description**: Continuous sensor data for Posey Creek collected from 2018-01-01T00:15:00Z to 2020-02-01T00:00:00Z. All continuous data were summarized to 15 minute observations by taking the mean of all observations within a 15 minute window.



**Data products used***:*

*ID*: NEON.DOM.SITE.DP4.00130.001

*Name*: Continuous discharge

*Description*: Continuous measurements of stream discharge calculated from a stage-discharge rating curve and sensor-based measurements of water surface elevation.

*Citation*: NEON (National Ecological Observatory Network). Continuous discharge (DP4.00130.001), RELEASE-2025. https://doi.org/10.48443/tr5z-x822. Dataset accessed from https://data.neonscience.org/data-products/DP4.00130.001/RELEASE-2025 on July 3, 2025.



*ID*: NEON.DOM.SITE.DP1.20053.001

*Name*: Temperature (PRT) in surface water

*Description*: Surface water temperature, available as one-, five-, and thirty-minute  averages, measured by a platinum resistance thermometer at the sensor location in lakes, wadeable and non-wadeable streams

*Citation*: NEON (National Ecological Observatory Network). Temperature (PRT) in surface water (DP1.20053.001), RELEASE-2025. https://doi.org/10.48443/0cm0-gh54. Dataset accessed from https://data.neonscience.org/data-products/DP1.20053.001/RELEASE-2025 on July 3, 2025.



*ID*: NEON.DOM.SITE.DP1.20288.001

*Name*: Water quality

*Description*: In situ sensor-based specific conductivity, concentration of chlorophyll a, dissolved oxygen content, fDOM concentration, pH, and turbidity, available as one- or five-minute instantaneous measurements in surface water of lakes, wadeable streams, and non-wadeable streams.

*Citation*: NEON (National Ecological Observatory Network). Water quality (DP1.20288.001), RELEASE-2025. https://doi.org/10.48443/03mj-t174. Dataset accessed from https://data.neonscience.org/data-products/DP1.20288.001/RELEASE-2025 on July 3, 2025.



*ID*: NEON.DOM.SITE.DP1.00002.001

*Name*: Single aspirated air temperature

*Description*: Air temperature, available as one- and thirty-minute averages of 1 Hz observations. Observations are made by sensors located at multiple heights on the tower infrastructure and by sensors located on the aquatic meteorological station. Temperature observations are made using platinum resistance thermometers, which are housed in a fan aspirated shield to reduce radiative bias.

*Citation*: NEON (National Ecological Observatory Network). Single aspirated air temperature (DP1.00002.001), RELEASE-2025. https://doi.org/10.48443/hejx-aa82. Dataset accessed from https://data.neonscience.org/data-products/DP1.00002.001/RELEASE-2025 on July 3, 2025.



###### PoseyCreek\_discrete.csv

**Description:** Discrete field collected discharge data for Posey Creek queried for the same time period as the continuous sensor data. Resulting data collected from 2018-01-23T14:05:00Z to 2020-01-07T15:26:00Z.



**Data products used:**

*ID*: NEON.DOM.SITE.DP1.20048.001

*Name*: Discharge field collection

*Description*: Discharge measurements from field-based surveys

*Citation*: NEON (National Ecological Observatory Network). Discharge field collection (DP1.20048.001), RELEASE-2025. https://doi.org/10.48443/tsq6-aw97. Dataset accessed from https://data.neonscience.org/data-products/DP1.20048.001/RELEASE-2025 on July 3, 2025.



